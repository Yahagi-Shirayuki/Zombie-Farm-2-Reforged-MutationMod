import { describe, expect, it } from "vitest";
import { gardenFertilizeChance } from "./ZombieField";

describe("gardenFertilizeChance", () => {
  it("adds monolith boost to Garden zombie tier chances", () => {
    expect(gardenFertilizeChance(1, 0.5)).toBeCloseTo(0.54);
    expect(gardenFertilizeChance(4, 0.5)).toBeCloseTo(0.58);
    expect(gardenFertilizeChance(5, 0.5)).toBeCloseTo(0.62);
  });

  it("clamps boosted chance to 100%", () => {
    expect(gardenFertilizeChance(5, 2)).toBe(1);
  });
});