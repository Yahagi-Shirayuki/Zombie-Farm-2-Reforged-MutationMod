import { describe, it, expect } from "vitest";
import { combineMasks, MODDED_MUTATIONS, mutationBonus, SLOT_MASK, type ModdedMutationDef } from "./mutations";

// Ground truth: combineZombieMutationFlag:withZombieFlag: / randMutation: — per slot,
// non-conflicting bits carry over; a same-slot conflict keeps the HIGHER bit value
// (higher-tier mutation), DETERMINISTICALLY (no RNG). One mutation per slot.

describe("combineMasks — deterministic per-slot inheritance", () => {
  it("carries a mutation from either parent when the other slot is empty", () => {
    expect(combineMasks(1, 0)).toBe(1); // only A (head)
    expect(combineMasks(0, 8)).toBe(8); // only B (arm)
  });

  it("unions mutations that occupy different slots", () => {
    // 1 = head (tomato), 8 = arm (turnip) — independent slots
    expect(combineMasks(1, 8)).toBe(9);
  });

  it("resolves a same-slot conflict to the higher bit (higher tier wins)", () => {
    // head slot: 1 (tomato) vs 256 (garlic) -> garlic
    expect(combineMasks(1, 256)).toBe(256);
    expect(combineMasks(256, 1)).toBe(256); // order-independent
  });

  it("keeps at most one mutation per slot in the child", () => {
    const child = combineMasks(1, 16); // both head (tomato vs potato)
    expect(child & SLOT_MASK.head).toBe(16); // the higher one, only
    // exactly one head bit set
    const headBits = SLOT_MASK.head & child;
    expect(headBits & (headBits - 1)).toBe(0);
  });

  it("is commutative across every slot", () => {
    const a = 1 | 8 | 1024; // head + arm + body
    const b = 256 | 4 | 2048; // head + hair_eye + neck
    expect(combineMasks(a, b)).toBe(combineMasks(b, a));
  });
});

describe("modded mutations", () => {
  it("keeps old single-stat modded mutations working", () => {
    MODDED_MUTATIONS.test_single = { id: "test_single", name: "Single Test", slot: "head", stat: "con", amount: 2 };
    try {
      expect(mutationBonus(0, ["test_single"])).toEqual({ str: 0, con: 2, dex: 0, wis: 0 });
    } finally {
      delete MODDED_MUTATIONS.test_single;
    }
  });

  it("allows modded mutations to grant two or three stats at once", () => {
    const temporary: Record<string, ModdedMutationDef> = {
      test_str_con: { id: "test_str_con", name: "STR/CON Test", slot: "head", bonuses: { str: 1, con: 2 } },
      test_dex_con: { id: "test_dex_con", name: "DEX/CON Test", slot: "arm", bonuses: { dex: 3, con: 4 } },
      test_str_dex: { id: "test_str_dex", name: "STR/DEX Test", slot: "body", bonuses: { str: 5, dex: 6 } },
      test_all: { id: "test_all", name: "All Test", slot: "neck", bonuses: { str: 7, dex: 8, con: 9, wis: 10 } },
    };

    for (const [id, def] of Object.entries(temporary)) MODDED_MUTATIONS[id] = def;
    try {
      expect(mutationBonus(0, ["test_str_con"])).toEqual({ str: 1, con: 2, dex: 0, wis: 0 });
      expect(mutationBonus(0, ["test_dex_con"])).toEqual({ str: 0, con: 4, dex: 3, wis: 0 });
      expect(mutationBonus(0, ["test_str_dex"])).toEqual({ str: 5, con: 0, dex: 6, wis: 0 });
      expect(mutationBonus(0, ["test_all"])).toEqual({ str: 7, con: 9, dex: 8, wis: 10 });
    } finally {
      for (const id of Object.keys(temporary)) delete MODDED_MUTATIONS[id];
    }
  });
});

// The Market's guaranteed-mutation line moved to zombie/statDisplay, because the
// number it shows has to be normalized — see marketMutationText.test.ts.
