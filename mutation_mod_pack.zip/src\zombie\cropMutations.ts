import { addMutationRef, MutationRef, MutationSet, slotOfRef } from "./mutations";

/** Mutation-bearing vegetable crops. Tier-4 visual variants intentionally share
 * the same mutation bit as their underlying Carrot/Cauliflower mutation. */
export const CROP_MUTATIONS: Readonly<Record<string, MutationRef | readonly MutationRef[]>> = {
  tomato: 1,
  onion: 2,
  carrot: 4,
  eyebiscus: 4,
  turnip: [8, "turnip_head", "turnip_eye"],
  potato: 16,
  coffee: 32,
  celery: 64,
  broccoli: 128,
  garlic: 256,
  cauliflower: 512,
  heartichoke: 512,
  lima_beans: 1024,
  venus_flytrap: 2048,
  dragon_fruit: 4096,
  //modded crop mutation
  corn: ["corn_head", "corn_arm"],
  breadfruit: "bread_neck",
  Bloodberry: "bloodberry_hair",
  skellyberry: "skellyberry_body",
  Spineapple: "spineapple_body",
  sampaguita: "sampaguita_hair",
  reddelicious: "apple_head",
  felonmelon: "melon_head"
};

export const CROP_MUTATION_CHANCE = 0.25;

/** Origin offsets for the eight plots whose edges or corners touch a plot. */
export function touchingPlotOffsets(plotSize: number): readonly (readonly [number, number])[] {
  return [
    [-plotSize, -plotSize], [0, -plotSize], [plotSize, -plotSize],
    [-plotSize, 0],                         [plotSize, 0],
    [-plotSize, plotSize],  [0, plotSize],  [plotSize, plotSize],
  ];
}

export interface CropMutationOptions {
  guaranteed?: boolean;
  headless?: boolean;
  random?: () => number;
}

/** Resolve all crop-adjacency mutations for one harvested zombie.
 *
 * Each adjacent crop adds 25 percentage points to its mutation's chance, capped
 * at 100%. Different non-conflicting mutations roll independently. If multiple
 * successful crops target the same anatomical slot, the lowest random roll wins;
 * this prevents plot iteration order from deciding the conflict. */
export function resolveCropMutations(
  baseMask: number,
  adjacentCropKeys: readonly string[],
  options: CropMutationOptions = {}
): number {
  return resolveCropMutationSet(baseMask, [], adjacentCropKeys, options).mask;
}

export function resolveCropMutationSet(
  baseMask: number,
  baseIds: readonly string[],
  adjacentCropKeys: readonly string[],
  options: CropMutationOptions = {}
): MutationSet {
  const counts = new Map<MutationRef, number>();
  for (const key of adjacentCropKeys) {
    const refs = CROP_MUTATIONS[key];
    if (!refs) continue;
    for (const ref of Array.isArray(refs) ? refs : [refs]) {
      counts.set(ref, (counts.get(ref) ?? 0) + 1);
    }
  }

  const random = options.random ?? Math.random;
  const successes: { ref: MutationRef; roll: number }[] = [];
  for (const [ref, count] of counts) {
    if (slotOfRef(ref) === null) continue;
    const roll = random();
    const chance = options.guaranteed ? 1 : Math.min(1, count * CROP_MUTATION_CHANCE);
    if (chance >= 1 || roll < chance) successes.push({ ref, roll });
  }

  successes.sort((a, b) => a.roll - b.roll || String(a.ref).localeCompare(String(b.ref)));
  let set: MutationSet = { mask: baseMask, ids: [...baseIds] };
  for (const success of successes) set = addMutationRef(set, success.ref, !!options.headless);
  return set;
}
