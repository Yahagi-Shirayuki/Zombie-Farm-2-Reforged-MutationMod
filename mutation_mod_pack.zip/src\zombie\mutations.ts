// ---------------------------------------------------------------------------
// Mutation system (data-derived from ZF2's Market.plist).
// ---------------------------------------------------------------------------
// A zombie's mutations are stored as a BITMASK: the game's `mutation` field is a
// power of two per mutation (Tomato=1, Onion=2, Carrot=4, ...). A zombie's full
// set is the bitwise-OR of its mutation bits, so the whole thing is one integer.
//
// Rules (locked in — see MUTATION_CATALOG_CORRECTED.md §4):
//   * One mutation per SLOT (head / hair_eye / arm / body / neck). The bitmask
//     alone would permit two head mutations at once (Tomato|Onion); that state
//     is ILLEGAL and every write here refuses it.
//   * Max 5 mutations (one per slot).
//   * Stat bonuses map: power/attack -> str, life -> con, speed -> dex, focus -> wis. Mutations
//     may grant more than one of those stats at once via `bonuses`.
//
// Acquisition: grow a zombie beside mutation-bearing crops, buy a pre-mutated
// Market zombie, or combine two zombies in the Zombie Pot.
// ---------------------------------------------------------------------------

export type Slot = "head" | "hair_eye" | "arm" | "body" | "neck";
export const SLOTS: Slot[] = ["head", "hair_eye", "arm", "body", "neck"];

export type Stat = "str" | "con" | "dex" | "wis";
export type MutationBonusMap = Partial<Record<Stat, number>>;
export type MutationRef = number | string;

export interface MutationDef {
  bit: number; // power-of-two mask value
  key: string; // stable id
  name: string; // display name of the resulting zombie
  slot: Slot;
  stat?: Stat; // backward-compatible single-stat bonus
  amount?: number; // bonus magnitude for `stat`
  bonuses?: MutationBonusMap; // raw multi-stat bonuses
}

export interface ModdedMutationDef {
  id: string;
  name: string;
  slot: Slot;
  stat?: Stat;
  amount?: number;
  // Raw stat bonuses. ig: bonuses: { str: int, con: int, dex: int, wis: int }
  bonuses?: MutationBonusMap;
}

// The 13 primary mutations, keyed by bit. Slot is authoritative from the bit
// (that is how ZF2 stores/enforces it); the stat mapping is power/attack->str,
// life->con, speed->dex. Eyebiscus (bit 4) and Heartichoke (bit 512) are Tier-4
// visual variants that reuse an existing bit, so they need no separate entry.
export const MUTATIONS: Record<number, MutationDef> = {
  1: { bit: 1, key: "tomato", name: "Tomatohead", slot: "head", bonuses: { str: 1, con: 1 } },
  2: { bit: 2, key: "onion", name: "Onionhead", slot: "head", bonuses: { dex: 1, con: 1 } },
  4: { bit: 4, key: "carrot", name: "Carrot-eyed", slot: "hair_eye", bonuses: { dex: 1, wis: 1 } },
  8: { bit: 8, key: "turnip", name: "Turnip-Arm", slot: "arm", bonuses: { str: 4, dex: -1 } },
  16: { bit: 16, key: "potato", name: "Potatohead", slot: "head", bonuses: { con: 4, dex: -1 } },
  32: { bit: 32, key: "coffee", name: "Coffeehead", slot: "head", bonuses: { dex: 3, wis: 1, con: -1 } },
  64: { bit: 64, key: "celery", name: "Celery-arms", slot: "arm", bonuses: { str: 3, con: 2, dex: -1 } },
  128: { bit: 128, key: "broccoli", name: "Broccohair", slot: "hair_eye", bonuses: { con: 3, wis: 2, dex: -1 } },
  256: { bit: 256, key: "garlic", name: "Garlichead", slot: "head", bonuses: { str: 4, con: 2, dex: -2 } },
  512: { bit: 512, key: "cauli", name: "Cauli-hair", slot: "hair_eye", bonuses: { con: 3, wis: 3, dex: -1 } },
  1024: { bit: 1024, key: "limabean", name: "Lima Bean", slot: "body", bonuses: { str: 3, con: 4, dex: -2 } },
  2048: { bit: 2048, key: "flytrap", name: "Flytrap", slot: "neck", bonuses: { str: 4, con: 3, wis: 1, dex: -2 } },
  4096: { bit: 4096, key: "dragon", name: "Dragon-arm", slot: "arm", bonuses: { str: 5, dex: 3, con: -2 } },
};
// Modded mutation stat
export const MODDED_MUTATIONS: Record<string, ModdedMutationDef> = {
  turnip_eye: { id: "turnip_eye", name: "Turnip-eyed", slot: "hair_eye", bonuses: { wis: 2, dex: 1, con: -1 } },
  turnip_head: { id: "turnip_head", name: "Turnip-head", slot: "head", bonuses: { str: 2, con: 2, dex: -1 } },
  bread_neck: { id: "bread_neck", name: "Bread neck", slot: "neck", bonuses: { con: 4, dex: -1 } },
  apple_head: { id: "apple_head", name: "Red-delicious Head", slot: "head", bonuses: { str: 2, dex: 2, wis: 1, con: -1 } },
  melon_head: { id: "melon_head", name: "Felon-Headon", slot: "head", bonuses: { con: 5, dex: -2 } },
  sampaguita_hair: { id: "sampaguita_hair", name: "Sampaguita hair", slot: "hair_eye", bonuses: { wis: 3, dex: 2, str: -1 } },
  corn_head: { id: "corn_head", name: "Corned head", slot: "head", bonuses: { con: 3, str: 2, dex: -1 } },
  corn_arm: { id: "corn_arm", name: "Corned Arms", slot: "arm", bonuses: { str: 4, con: 1, dex: -1 } },
  spineapple_body: { id: "spineapple_body", name: "Spine-ap-body", slot: "body", bonuses: { str: 3, con: 3, dex: 1, wis: -2 } },
  bloodberry_hair: { id: "bloodberry_hair", name: "Bloody-hairy", slot: "hair_eye", bonuses: { str: 4, con: 2, wis: 1, dex: -2 } },
  skellyberry_body: { id: "skellyberry_body", name: "Skelly-belly", slot: "body", bonuses: { con: 5, str: 3, dex: -2 } },
};

/** All known mutation bits (the ones we resolve). */
export const ALL_BITS: number[] = Object.keys(MUTATIONS).map(Number);
export const ALL_MODDED_MUTATION_IDS: string[] = Object.keys(MODDED_MUTATIONS);

/** Bitmask of every mutation belonging to a slot. Used to test slot occupancy. */
export const SLOT_MASK: Record<Slot, number> = (() => {
  const m: Record<Slot, number> = { head: 0, hair_eye: 0, arm: 0, body: 0, neck: 0 };
  for (const bit of ALL_BITS) m[MUTATIONS[bit].slot] |= bit;
  return m;
})();

/** The slot a mutation bit occupies, or null if the bit is unknown. */
export function slotOf(bit: number): Slot | null {
  return MUTATIONS[bit]?.slot ?? null;
}

export function slotOfRef(ref: MutationRef): Slot | null {
  return typeof ref === "number" ? slotOf(ref) : MODDED_MUTATIONS[ref]?.slot ?? null;
}

/** Every individual mutation bit set in a mask, low bit first. */
export function bitsOf(mask: number): number[] {
  return ALL_BITS.filter((b) => (mask & b) !== 0);
}

export function normalizeMutationIds(ids: readonly unknown[] | undefined): string[] {
  if (!ids) return [];
  return [...new Set(ids.filter((id): id is string =>
    typeof id === "string" && !!MODDED_MUTATIONS[id]
  ))];
}

export function mutationRefs(mask: number, ids?: readonly string[]): MutationRef[] {
  return [...bitsOf(mask), ...normalizeMutationIds(ids)];
}

/** Resolved mutation defs present in a mask (skips unknown/unmapped bits). */
export function mutationsOf(mask: number): MutationDef[] {
  return bitsOf(mask).map((b) => MUTATIONS[b]);
}

export function mutationNameOf(ref: MutationRef): string {
  return typeof ref === "number" ? MUTATIONS[ref]?.name ?? "" : MODDED_MUTATIONS[ref]?.name ?? "";
}

/** Which slots are already filled in a mask. */
export function occupiedSlots(mask: number): Set<Slot> {
  const s = new Set<Slot>();
  for (const slot of SLOTS) if ((mask & SLOT_MASK[slot]) !== 0) s.add(slot);
  return s;
}

export function occupiedMutationSlots(mask: number, ids?: readonly string[]): Set<Slot> {
  const slots = occupiedSlots(mask);
  for (const id of normalizeMutationIds(ids)) slots.add(MODDED_MUTATIONS[id].slot);
  return slots;
}

/** Number of mutations carried (0..5). */
export function mutationCount(mask: number, ids?: readonly string[]): number {
  return mutationRefs(mask, ids).length;
}

/** A mask is fully mutated when all five slots are filled. */
export function isFullyMutated(mask: number, ids?: readonly string[]): boolean {
  return occupiedMutationSlots(mask, ids).size === SLOTS.length;
}

// A HEADLESS zombie has no head to mutate: it can only carry body, arm, and neck
// mutations — never head or hair/eye (report §11). These are the slots it MAY hold
// and the bitmask of everything it may NOT.
export const HEADLESS_SLOTS: ReadonlySet<Slot> = new Set<Slot>(["body", "arm", "neck"]);
export const HEADLESS_FORBIDDEN_MASK = SLOT_MASK.head | SLOT_MASK.hair_eye;

/** Is a slot allowed on a (possibly headless) zombie? Headless bars head/hair_eye. */
export function slotAllowed(slot: Slot, isHeadless: boolean): boolean {
  return !isHeadless || HEADLESS_SLOTS.has(slot);
}

/**
 * Drop mutations a headless zombie can't hold (head + hair/eye). A no-op for a
 * normal zombie. Applied wherever a mask lands on a unit, so a headless combine
 * result simply never carries a head/hair-eye mutation.
 */
export function applyHeadlessRestriction(mask: number, isHeadless: boolean): number {
  return isHeadless ? mask & ~HEADLESS_FORBIDDEN_MASK : mask;
}

export function applyHeadlessIdRestriction(ids: readonly string[] | undefined, isHeadless: boolean): string[] {
  const normalized = normalizeMutationIds(ids);
  return isHeadless ? normalized.filter((id) => HEADLESS_SLOTS.has(MODDED_MUTATIONS[id].slot)) : normalized;
}

/**
 * Can `bit` legally be added to `mask`? False if the bit is unknown, its slot is
 * already occupied (one-per-slot), or the zombie is headless and the slot is a
 * head/hair-eye slot. Adding a bit already present is a no-op and reported legal.
 */
export function canReceive(mask: number, bit: number, isHeadless = false): boolean {
  const slot = slotOf(bit);
  if (slot === null) return false;
  if (!slotAllowed(slot, isHeadless)) return false; // headless: no head/hair_eye
  if ((mask & bit) !== 0) return true; // already have exactly this one
  return (mask & SLOT_MASK[slot]) === 0; // slot must be empty
}

export function canReceiveRef(
  mask: number,
  ids: readonly string[] | undefined,
  ref: MutationRef,
  isHeadless = false,
): boolean {
  const slot = slotOfRef(ref);
  if (slot === null) return false;
  if (!slotAllowed(slot, isHeadless)) return false;
  if (typeof ref === "number" && (mask & ref) !== 0) return true;
  if (typeof ref === "string" && normalizeMutationIds(ids).includes(ref)) return true;
  return !occupiedMutationSlots(mask, ids).has(slot);
}

/**
 * Add `bit` to `mask`, enforcing one-per-slot (and the headless restriction when
 * `isHeadless`). If the write is illegal `mask` is returned unchanged (the caller
 * decides conflict resolution — see combineMasks). Returns the new mask.
 */
export function addMutation(mask: number, bit: number, isHeadless = false): number {
  return canReceive(mask, bit, isHeadless) ? mask | bit : mask;
}

export interface MutationSet {
  mask: number;
  ids: string[];
}

export function addMutationRef(
  set: MutationSet,
  ref: MutationRef,
  isHeadless = false,
): MutationSet {
  if (!canReceiveRef(set.mask, set.ids, ref, isHeadless)) return set;
  if (typeof ref === "number") return { ...set, mask: set.mask | ref };
  return { ...set, ids: normalizeMutationIds([...set.ids, ref]) };
}

/** Human-readable list, e.g. "Onionhead, Celery-arms". "" when unmutated. */
export function mutationLabel(mask: number, ids?: readonly string[]): string {
  return mutationRefs(mask, ids)
    .map(mutationNameOf)
    .filter(Boolean)
    .join(", ");
}

// The Market's guaranteed-mutation line lives in zombie/statDisplay
// (mutationMarketDescription). It belongs there because the number it shows must be
// NORMALIZED — a mutation's raw 1–4 points are never what the player sees on a stat
// tile — and this module deliberately knows nothing about display normalization.

const MUTATION_STATS: Stat[] = ["str", "con", "dex", "wis"];

function addMutationDefBonus(
  out: Record<Stat, number>,
  mutation: { stat?: Stat; amount?: number; bonuses?: MutationBonusMap },
): void {
  if (mutation.bonuses) {
    for (const stat of MUTATION_STATS) out[stat] += mutation.bonuses[stat] ?? 0;
    return;
  }
  if (mutation.stat && mutation.amount !== undefined) out[mutation.stat] += mutation.amount;
}

/** Summed stat bonuses from all mutations in a mask. */
export function mutationBonus(mask: number, ids?: readonly string[]): Record<Stat, number> {
  const b: Record<Stat, number> = { str: 0, con: 0, dex: 0, wis: 0 };
  for (const m of mutationsOf(mask)) addMutationDefBonus(b, m);
  for (const id of normalizeMutationIds(ids)) addMutationDefBonus(b, MODDED_MUTATIONS[id]);
  return b;
}

/**
 * Zombie Pot slot-inheritance: combine two parent masks into a child mask.
 *   - Non-conflicting slot (only one parent has it): child inherits it.
 *   - Same mutation on both: child inherits it.
 *   - Different mutations in the same slot: keep the HIGHER bit value.
 * One-per-slot always holds. This is DETERMINISTIC — no RNG.
 *
 * GROUND TRUTH (from the shipped iOS binary — `ZFZombieCombiner
 * combineZombieMutationFlag:withZombieFlag:` + `randMutation:flag1:flag2:controlFlag:`;
 * see docs/mechanics/BINARY_RE_METHODOLOGY.md): the real `randMutation:` contains no
 * `rand`/`arc4random` call. A same-slot conflict resolves via `cmp; movle` = MAX of the
 * two mutation bits. Because bits are numbered in tier order (Tomato=1 … Dragon=0x1000,
 * variants higher), the higher bit is the higher-tier mutation — so the better mutation
 * always wins its slot. (Earlier builds guessed a 50/50 coin flip here; that was wrong.)
 */
export function combineMasks(a: number, b: number): number {
  let child = 0;
  for (const slot of SLOTS) {
    const am = a & SLOT_MASK[slot];
    const bm = b & SLOT_MASK[slot];
    if (am === 0 && bm === 0) continue; // neither -> empty slot
    if (am === 0) { child |= bm; continue; } // only B
    if (bm === 0) { child |= am; continue; } // only A
    child |= Math.max(am, bm); // both -> higher-tier bit wins (deterministic)
  }
  return child;
}

function mutationRank(ref: MutationRef): number {
  if (typeof ref === "number") return ref;
  const index = ALL_MODDED_MUTATION_IDS.indexOf(ref);
  return 1_000_000_000 + (index < 0 ? 0 : index);
}

export function combineMutationSets(
  aMask: number,
  aIds: readonly string[] | undefined,
  bMask: number,
  bIds: readonly string[] | undefined,
): MutationSet {
  const best = new Map<Slot, MutationRef>();
  for (const ref of [...mutationRefs(aMask, aIds), ...mutationRefs(bMask, bIds)]) {
    const slot = slotOfRef(ref);
    if (!slot) continue;
    const current = best.get(slot);
    if (current === undefined || mutationRank(ref) > mutationRank(current)) best.set(slot, ref);
  }

  let result: MutationSet = { mask: 0, ids: [] };
  for (const ref of best.values()) result = addMutationRef(result, ref);
  return result;
}
