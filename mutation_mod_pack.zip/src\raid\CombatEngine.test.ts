import { describe, it, expect } from "vitest";
import { resolveRaid, buildEnemyUnits, buildPlayerUnits } from "./CombatEngine";
import type { CombatUnit } from "./types";
import type { OwnedZombie } from "../zombie/types";
import { MODDED_MUTATIONS, mutationBonus, type ModdedMutationDef } from "../zombie/mutations";
import { minimumResolvedRawStat } from "../zombie/traits";

// resolveRaid is the deterministic instant-resolver. These tests pin the outcome
// direction and, crucially, that the recovered damage formula
// (max(0, dmg − armor) × (1 − DR)) is wired into the hit step.

function mk(over: Partial<CombatUnit> & { id: string; team: "player" | "enemy" }): CombatUnit {
  return {
    sourceKey: over.id,
    name: over.id,
    str: 10,
    dex: 5,
    con: 10,
    focus: 0,
    hp: 100,
    maxHp: 100,
    attackCooldownMs: 1000,
    attacks: [{ name: "", frequency: 1, mult: 1 }],
    isBoss: false,
    alive: true,
    isGarden: false,
    isHeadless: false,
    abilities: [],
    ...over,
  };
}

describe("resolveRaid outcome direction", () => {
  it("a strong army beats a weak wave", () => {
    const player = [mk({ id: "p", team: "player", str: 50, con: 50 })];
    const enemy = [mk({ id: "e", team: "enemy", str: 2, con: 5 })];
    expect(resolveRaid(player, enemy).win).toBe(true);
  });

  it("a weak army loses to a strong wave", () => {
    const player = [mk({ id: "p", team: "player", str: 2, con: 5 })];
    const enemy = [mk({ id: "e", team: "enemy", str: 50, con: 50 })];
    expect(resolveRaid(player, enemy).win).toBe(false);
  });
});

describe("damage formula is wired into the resolver", () => {
  const player = () => [mk({ id: "p", team: "player", str: 20, con: 30, dex: 10 })];

  it("near-total damage reduction on the enemy flips a win into a loss", () => {
    const winnable = resolveRaid(player(), [mk({ id: "e", team: "enemy", str: 3, con: 20 })]);
    expect(winnable.win).toBe(true);

    const armored = resolveRaid(player(), [
      mk({ id: "e", team: "enemy", str: 3, con: 20, damageReduction: 0.99 }),
    ]);
    expect(armored.win).toBe(false); // player's damage is reduced to ~0 → can't kill
  });

  it("flat armor ≥ the attacker's per-hit damage blocks all of it", () => {
    // player hitDamage = finalPower(str20×10) × mult(1) × K(0.7) = 140; armor 200 absorbs it.
    const blocked = resolveRaid(player(), [
      mk({ id: "e", team: "enemy", str: 3, con: 20, armor: 200 }),
    ]);
    expect(blocked.win).toBe(false);
    expect(blocked.playerDamage).toBe(0);
  });
});

describe("enemies engage one at a time (army concentration matters)", () => {
  const army = (team: "player" | "enemy", n: number) =>
    Array.from({ length: n }, (_, i) => mk({ id: `${team}${i}`, team, str: 10, con: 10 }));

  it("an even-stat army beats a same-size wave by focusing it down one at a time", () => {
    // Under an all-at-once wave this is a loss; one-at-a-time, the army's concentrated
    // fire wins with survivors.
    const r = resolveRaid(army("player", 5), army("enemy", 5));
    expect(r.win).toBe(true);
    expect(r.enemiesBeaten).toBe(5);
    expect(r.survivors.length).toBeGreaterThan(0);
  });

  it("still loses when badly outnumbered by equal units", () => {
    const r = resolveRaid(army("player", 1), army("enemy", 4));
    expect(r.win).toBe(false);
  });

  it("faces the wave sequentially — a lone zombie can chip several before falling", () => {
    // Weak-but-many player vs one tanky enemy: the whole army piles the single enemy.
    const tank = mk({ id: "boss", team: "enemy", str: 8, con: 40 });
    const r = resolveRaid(army("player", 6), [tank]);
    expect(r.win).toBe(true);
  });
});

describe("weighted raid populations", () => {
  it("preserves the authored population exactly after weight apportionment", () => {
    const stats = Object.fromEntries(["a", "b", "c"].map((key) => [key, {
      str: 1, dex: 1, con: 1, attacks: [],
    }]));
    const units = buildEnemyUnits({
      enemyKeys: [],
      population: 11,
      weighted: [
        { enemy: "a", frequency: 50 },
        { enemy: "b", frequency: 33 },
        { enemy: "c", frequency: 17 },
      ],
    }, stats, {});
    expect(units).toHaveLength(11);
    expect(units.filter((unit) => unit.sourceKey === "a")).toHaveLength(5);
    expect(units.filter((unit) => unit.sourceKey === "b")).toHaveLength(4);
    expect(units.filter((unit) => unit.sourceKey === "c")).toHaveLength(2);
  });
});

describe("buildPlayerUnits — level-scaling is applied", () => {
  const headless = (): OwnedZombie[] => [
    {
      id: "z1",
      key: "ZombieActorHeadless",
      name: "Bob",
      typeName: "Skull Head",
      group: "Headless",
      className: "Green",
      classColor: "#000",
      mutation: 0,
      str: 11,
      dex: 1,
      con: 29.7, // base con; Headless con floor is 11
      focus: 100,
      invasions: 0,
      col: 0,
      row: 0,
    },
  ];

  it("a low-level army fights weaker than a maxed one (con ramps HP)", () => {
    const lo = buildPlayerUnits(headless(), { playerLevel: 8 })[0]; // con -> floor 11
    const hi = buildPlayerUnits(headless(), { playerLevel: 25 })[0]; // con -> base 29.7
    expect(lo.maxHp).toBeLessThan(hi.maxHp);
    expect(lo.maxHp).toBe(1100); // con 11 × 100 (ground-truth hitPointsTotal)
    expect(hi.maxHp).toBe(2970); // con 29.7 × 100
  });

  it("omitting playerLevel fights at full base stats (no scaling)", () => {
    const full = buildPlayerUnits(headless(), {})[0];
    expect(full.maxHp).toBe(2970);
  });

  it("does not scale focus (only str/con/dex)", () => {
    const lo = buildPlayerUnits(headless(), { playerLevel: 8 })[0];
    expect(lo.focus).toBe(100); // unchanged despite low level
  });

  it("applies equipped farmer head strength and life bonuses", () => {
    const base = buildPlayerUnits(headless())[0];
    const buffed = buildPlayerUnits(headless(), {
      farmerStrengthMult: 1.1,
      farmerLifeMult: 1.1,
    })[0];
    expect(buffed.str).toBeCloseTo(base.str * 1.1);
    expect(buffed.maxHp).toBeCloseTo(base.maxHp * 1.1);
  });

  it("carries the owned mutation mask into the raid combat unit", () => {
    const mutated = headless()[0];
    mutated.group = "Regular";
    mutated.mutation = 4 | 64;
    expect(buildPlayerUnits([mutated])[0].mutation).toBe(4 | 64);
  });
});

// Ground truth: `-[ZombieActor modifyStats:]` chains modifyStatWithLevelScale: →
// modifyStatWithFarmerHeads: → modifyStatWithAbilities: → modifyStatWithRank: →
// modifyStatWithMutations:, so a mutation's flat bonus lands LAST — never scaled by the
// level ramp, never multiplied by veterancy. `OwnedZombie.str/con/dex` already include
// the bonus (makeOwned bakes it in for the detail card), so buildPlayerUnits peels it
// off, runs the chain, and adds it back. Baking it in before the ramp — the old
// behaviour — left a full 5-slot set worth ~25 % of its face value at level 12.
describe("buildPlayerUnits — mutations apply last, as a flat bonus", () => {
  // Garlichead (+3 str, head) | Dragon-arm (+4 str, arm) | Carrot-eyed (+1 dex, hair_eye)
  const MASK = 256 | 4096 | 4;
  const MUT = mutationBonus(MASK);
  const MUT_STR = MUT.str;
  const MUT_DEX = MUT.dex;

  /** A Blue Regular (base str 5 / dex 2 / con 5 — exactly the Regular endpoints, so the
   *  level ramp is a no-op on the base and any level dependence must come from the
   *  mutation). `str`/`dex` carry the bonus, as makeOwned produces them. */
  const mutant = (over: Partial<OwnedZombie> = {}): OwnedZombie[] => [
    {
      id: "m1", key: "ZombieActorRegularTier2", name: "Zyborg", typeName: "Zyborg",
      group: "Regular", className: "Blue", classColor: "#5aa8ff",
      mutation: MASK,
      str: 5 + MUT_STR, dex: 2 + MUT_DEX, con: 5,
      focus: 100, invasions: 0, col: 0, row: 0,
      ...over,
    },
  ];

  it("pays the mutation at face value well below level 25", () => {
    const lo = buildPlayerUnits(mutant(), { playerLevel: 12 })[0];
    expect(lo.str).toBeCloseTo(5 + MUT_STR);
    expect(lo.dex).toBeCloseTo(2 + MUT_DEX);
  });

  it("pays the same mutation at level 12 and level 25", () => {
    const lo = buildPlayerUnits(mutant(), { playerLevel: 12 })[0];
    const hi = buildPlayerUnits(mutant(), { playerLevel: 25 })[0];
    expect(lo.str).toBeCloseTo(hi.str);
  });

  it("veterancy multiplies the base stat only, not the flat mutation", () => {
    const master = buildPlayerUnits(mutant({ invasions: 5 }), { playerLevel: 25 })[0];
    expect(master.str).toBeCloseTo(5 * 1.25 + MUT_STR); // 13.25, not 12 × 1.25 = 15
  });


  it("applies wis to focus as a flat mutation bonus", () => {
    const previous = MODDED_MUTATIONS.test_focus;
    MODDED_MUTATIONS.test_focus = {
      id: "test_focus", name: "Focus Test", slot: "head", bonuses: { wis: 10 },
    } as ModdedMutationDef;
    try {
      const [built] = buildPlayerUnits(mutant({
        mutation: 0,
        mutationIds: ["test_focus"],
        focus: 80,
      }), { playerLevel: 12 });
      expect(built.focus).toBe(80);
    } finally {
      if (previous) MODDED_MUTATIONS.test_focus = previous;
      else delete MODDED_MUTATIONS.test_focus;
    }
  });

  it("floors debuffed combat stats before deriving raid damage, HP, and speed", () => {
    const previous = MODDED_MUTATIONS.test_raid_debuff;
    MODDED_MUTATIONS.test_raid_debuff = {
      id: "test_raid_debuff", name: "Raid Debuff", slot: "head",
      bonuses: { str: -100, dex: -100, con: -100 },
    } as ModdedMutationDef;
    try {
      const [built] = buildPlayerUnits(mutant({
        mutation: 0,
        mutationIds: ["test_raid_debuff"],
        str: -95,
        dex: -98,
        con: -95,
      }), { playerLevel: 25 });
      expect(built.str).toBeCloseTo(minimumResolvedRawStat("str"));
      expect(built.dex).toBeCloseTo(minimumResolvedRawStat("dex"));
      expect(built.con).toBeCloseTo(minimumResolvedRawStat("con"));
      expect(built.maxHp).toBeGreaterThan(1);
      expect(Number.isFinite(built.attackCooldownMs)).toBe(true);
    } finally {
      if (previous) MODDED_MUTATIONS.test_raid_debuff = previous;
      else delete MODDED_MUTATIONS.test_raid_debuff;
    }
  });
  it("still ramps the UNMUTATED base while paying the mutation in full", () => {
    // Headless con: endpoint 11, base 29.7, +3 con from Cauli-hair -> listed 32.7.
    const mask = 512;
    const head = (): OwnedZombie[] => [
      { ...mutant()[0], group: "Headless", key: "ZombieActorHeadless", mutation: mask,
        str: 11, dex: 1, con: 29.7 + 3 },
    ];
    expect(buildPlayerUnits(head(), { playerLevel: 8 })[0].maxHp).toBe(1400); // (11 + 3) × 100
    expect(buildPlayerUnits(head(), { playerLevel: 25 })[0].maxHp).toBe(3270); // (29.7 + 3) × 100
  });
});

describe("buildPlayerUnits — binary-authentic zombie abilities", () => {
  const owned = (
    id: string,
    group: string,
    className: string,
    over: Partial<OwnedZombie> = {}
  ): OwnedZombie => ({
    id,
    key: `ZombieActor${group}${className}`,
    name: id,
    typeName: id,
    group,
    className,
    classColor: "#000",
    mutation: 0,
    str: 10,
    dex: 2,
    con: 20,
    focus: 50,
    invasions: 0,
    col: 0,
    row: 0,
    ...over,
  });
  const unlocked = () => true;

  it("Chivalry buffs Girl stats but not its Regular carrier", () => {
    const girl = owned("girl", "Female", "Green");
    const carrier = owned("knight", "Regular", "Blue");
    const solo = buildPlayerUnits([girl], { abilityUnlocked: unlocked })[0];
    const [buffed, regular] = buildPlayerUnits([girl, carrier], { abilityUnlocked: unlocked });
    expect(buffed.str).toBeCloseTo(solo.str * 1.10);
    expect(buffed.dex).toBeCloseTo(solo.dex * 1.10);
    expect(buffed.maxHp).toBeCloseTo(solo.maxHp * 1.10);
    expect(regular.str).toBeCloseTo(10 * 1.05); // only its own +5% All Stats
  });

  it("Grace buffs Regular zombies", () => {
    const regular = owned("regular", "Regular", "Green");
    const carrier = owned("grace", "Female", "Blue");
    const solo = buildPlayerUnits([regular], { abilityUnlocked: unlocked })[0];
    const [buffed] = buildPlayerUnits([regular, carrier], { abilityUnlocked: unlocked });
    expect(buffed.str).toBeCloseTo(solo.str * 1.10);
    expect(buffed.dex).toBeCloseTo(solo.dex * 1.10);
    expect(buffed.maxHp).toBeCloseTo(solo.maxHp * 1.10);
  });

  it("stacks duplicate Chivalry and Grace carriers additively", () => {
    const girl = owned("girl", "Female", "Green");
    const knightA = owned("knight-a", "Regular", "Blue");
    const knightB = owned("knight-b", "Regular", "Blue");
    const regular = owned("regular", "Regular", "Green");
    const graceA = owned("grace-a", "Female", "Blue");
    const graceB = owned("grace-b", "Female", "Blue");
    const girlSolo = buildPlayerUnits([girl], { abilityUnlocked: unlocked })[0];
    const regularSolo = buildPlayerUnits([regular], { abilityUnlocked: unlocked })[0];
    const [buffedGirl] = buildPlayerUnits([girl, knightA, knightB], { abilityUnlocked: unlocked });
    const [buffedRegular] = buildPlayerUnits([regular, graceA, graceB], { abilityUnlocked: unlocked });
    expect(buffedGirl.str).toBeCloseTo(girlSolo.str * 1.20);
    expect(buffedGirl.dex).toBeCloseTo(girlSolo.dex * 1.20);
    expect(buffedGirl.maxHp).toBeCloseTo(girlSolo.maxHp * 1.20);
    expect(buffedRegular.str).toBeCloseTo(regularSolo.str * 1.20);
    expect(buffedRegular.dex).toBeCloseTo(regularSolo.dex * 1.20);
    expect(buffedRegular.maxHp).toBeCloseTo(regularSolo.maxHp * 1.20);
  });

  it("Protect reduces damage for every group except Headless", () => {
    const regular = owned("regular", "Regular", "Green");
    const headless = owned("protector", "Headless", "Blue");
    const built = buildPlayerUnits([regular, headless], { abilityUnlocked: unlocked });
    expect(built[0].damageReduction).toBeCloseTo(0.20);
    expect(built[1].damageReduction).toBe(0);
  });

  it("stacks duplicate Protect carriers additively", () => {
    const regular = owned("regular", "Regular", "Green");
    const protectA = owned("protector-a", "Headless", "Blue");
    const protectB = owned("protector-b", "Headless", "Blue");
    const [buffed] = buildPlayerUnits([regular, protectA, protectB], { abilityUnlocked: unlocked });
    expect(buffed.damageReduction).toBeCloseTo(0.40);
  });

  it("Fortitude gives Headless zombies 10% Life", () => {
    const headless = owned("headless", "Headless", "Green");
    const garden = owned("garden", "Garden", "Blue");
    const solo = buildPlayerUnits([headless], { abilityUnlocked: unlocked })[0];
    const [buffed] = buildPlayerUnits([headless, garden], { abilityUnlocked: unlocked });
    expect(buffed.maxHp).toBeCloseTo(solo.maxHp * 1.10);
  });

  it("stacks duplicate Fortitude carriers additively", () => {
    const headless = owned("headless", "Headless", "Green");
    const gardenA = owned("garden-a", "Garden", "Blue");
    const gardenB = owned("garden-b", "Garden", "Blue");
    const solo = buildPlayerUnits([headless], { abilityUnlocked: unlocked })[0];
    const [buffed] = buildPlayerUnits([headless, gardenA, gardenB], { abilityUnlocked: unlocked });
    expect(buffed.maxHp).toBeCloseTo(solo.maxHp * 1.20);
  });

  it("Turbo doubles walking only, without changing DEX or attack cadence", () => {
    const turbo = owned("turbo", "Headless", "Red");
    const base = owned("base", "Headless", "Green");
    const [fast] = buildPlayerUnits([turbo], { abilityUnlocked: unlocked });
    const [normal] = buildPlayerUnits([base], { abilityUnlocked: unlocked });
    expect(fast.dex).toBeCloseTo(normal.dex);
    expect(fast.attackCooldownMs).toBeCloseTo(normal.attackCooldownMs);
    expect(fast.walkingSpeedMult).toBe(2);
  });
});

// ---------------------------------------------------------------------------
// Enemy cadence. Ground truth: one attack cycle is exactly getFightAttackSpeed —
// speedMultiplier × (1/dex) for an enemy — with no animation gate. (This replaced
// the old ENEMY_ATTACK_PACE=2 fudge, which halved every enemy's sustained DPS.)

describe("buildEnemyUnits — attack cadence", () => {
  const stats = {
    Farmhand: { str: 2, dex: 1, con: 3, attacks: [{ name: "poke", frequency: 100 }] },
    Lumberjack: {
      str: 1.5,
      dex: 2,
      con: 4,
      attacks: [
        { name: "slice", frequency: 90 },
        { name: "special", frequency: 10 },
      ],
    },
    PirateStageActorScallywag: { str: 50, dex: 0.5, con: 40, attacks: [{ name: "poke", frequency: 100 }] },
  };
  const attacks = {
    poke: {},
    slice: {},
    special: { damageMultiplier: 1.5, speedMultiplier: 5 },
  };
  const build = (key: string, opts = {}) =>
    buildEnemyUnits({ enemyKeys: [key] }, stats, attacks, opts)[0];

  it("runs on the raw 1/dex clock — twice as often as an equal-dex zombie", () => {
    expect(build("Farmhand").attackCooldownMs).toBeCloseTo(1000); // 1.0 / dex 1
    expect(build("Lumberjack").attackCooldownMs / 2).toBeCloseTo(350); // see below
  });

  it("folds each attack's speedMultiplier in, so a heavy swing is slower AND harder", () => {
    const lumberjack = build("Lumberjack");
    // cycle = mean(0.9×1 + 0.1×5) × (1/2 s) = 1.4 × 500 ms
    expect(lumberjack.attackCooldownMs).toBeCloseTo(700);
    // damage = str1.5×10 × mean(0.9×1 + 0.1×1.5) = 15 × 1.05
    expect(lumberjack.attacks[0].mult).toBeCloseTo(1.05);
    // Sustained DPS matches the real renewal process E[dmg]/E[cycle] = 22.5.
    const dps = (lumberjack.str * 10 * lumberjack.attacks[0].mult) /
      (lumberjack.attackCooldownMs / 1000);
    expect(dps).toBeCloseTo(22.5, 1);
  });

  it("flags the Scallywag as mirroring its opponent's speed", () => {
    expect(build("PirateStageActorScallywag").mirrorsOpponentSpeed).toBe(true);
    expect(build("Farmhand").mirrorsOpponentSpeed).toBe(false);
  });

  it("speeds Old McDonnell's farm up as the player out-levels it — and only that raid", () => {
    expect(build("Farmhand", { raidId: 1, playerLevel: 5 }).attackCooldownMs).toBeCloseTo(1000);
    expect(build("Farmhand", { raidId: 1, playerLevel: 10 }).attackCooldownMs).toBeCloseTo(660);
    expect(build("Farmhand", { raidId: 1, playerLevel: 15 }).attackCooldownMs).toBeCloseTo(440);
    expect(build("Farmhand", { raidId: 3, playerLevel: 40 }).attackCooldownMs).toBeCloseTo(1000);
  });
});

describe("resolveRaid — recovered cadence rules reach the resolver", () => {
  // An unkillable, harmless punching bag: the fight runs to the sim cap, so
  // `playerDamage` is a clean measure of the army's sustained output.
  const bag = () => mk({ id: "e", team: "enemy", str: 0, hp: 1e9, maxHp: 1e9 });
  const zombie = (i: number) =>
    mk({ id: `p${i}`, team: "player", str: 5, hp: 1e9, maxHp: 1e9, attackCooldownMs: 1000 });

  it("a rear zombie's depth band slows it down as well as softening it", () => {
    const front = resolveRaid(Array.from({ length: 5 }, (_, i) => zombie(i)), [bag()]);
    const deep = resolveRaid(Array.from({ length: 16 }, (_, i) => zombie(i)), [bag()]);
    // 16 zombies out-damage 5 — but nowhere near 3.2×, because everything past the
    // front five hits softer (×0.85/0.7/0.55) AND slower (×1.425/2/4).
    expect(deep.playerDamage).toBeGreaterThan(front.playerDamage);
    expect(deep.playerDamage).toBeLessThan(front.playerDamage * 3.2);
    expect(deep.playerDamage / front.playerDamage).toBeCloseTo(1.97, 1);
  });

  it("a Scallywag mirrors its opponent instead of using its own dex", () => {
    // The zombie swings every 2 s and dies to two hits; the enemy's own clock is 2 s.
    const foe = () => mk({ id: "p", team: "player", str: 5, hp: 1000, maxHp: 1000, attackCooldownMs: 2000 });
    const enemy = (mirror: boolean) =>
      mk({
        id: "e",
        team: "enemy",
        str: 50,
        hp: 1e9,
        maxHp: 1e9,
        attackCooldownMs: 2000,
        mirrorsOpponentSpeed: mirror,
      });
    // Mirrored against a 2 s zombie the Scallywag runs at 2²/0.8 = 5 s, not its own
    // 2 s — so that zombie lives long enough to land far more swings.
    const vsMirror = resolveRaid([foe()], [enemy(true)]);
    const vsPlain = resolveRaid([foe()], [enemy(false)]);
    expect(vsMirror.playerDamage).toBeGreaterThan(vsPlain.playerDamage);
  });
});
